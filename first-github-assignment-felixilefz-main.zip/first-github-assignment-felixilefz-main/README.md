# Welcome to our GitHub classroom!

Do the following to Complete this assignment:

1. Begin editing this file by clicking the 'pen' symbol above.

2. Enter your First Name: Felix

3. Enter your favourite animal: Dolphin

4. Now click the green 'commit changes' button at the bottom.

5. Done!
